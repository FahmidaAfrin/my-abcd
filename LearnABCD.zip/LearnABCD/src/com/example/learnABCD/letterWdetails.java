package com.example.learnABCD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class letterWdetails extends Activity implements OnClickListener
{
	
	
	ImageButton letterX;
	Button mainmenuW;
@Override
protected void onCreate(Bundle savedInstanceState) 
{
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.w);
	
	letterX=(ImageButton)findViewById(R.id.imageButton1);
	mainmenuW=(Button)findViewById(R.id.mainmenuW);
	mainmenuW.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentmainmenuw=new Intent(letterWdetails.this,LearnABCDActivity.class);
			startActivity(Intentmainmenuw);
			
		}
	});
	
	
letterX.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentx=new Intent(letterWdetails.this,letterXdetails.class);
			startActivity(Intentx);			
		}
	});

	
}


@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
