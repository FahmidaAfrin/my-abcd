package com.example.learnABCD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class letterRdetails extends Activity implements OnClickListener
{
	
	
	ImageButton letterS;
	Button mainmenuR;
@Override
protected void onCreate(Bundle savedInstanceState) 
{
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.r);
	
	letterS=(ImageButton)findViewById(R.id.imageButton1);
	mainmenuR=(Button)findViewById(R.id.mainmenuR);
	mainmenuR.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentmainmenur=new Intent(letterRdetails.this,LearnABCDActivity.class);
			startActivity(Intentmainmenur);
			
		}
	});
	
	
letterS.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intents=new Intent(letterRdetails.this,letterSdetails.class);
			startActivity(Intents);			
		}
	});

	
}


@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
