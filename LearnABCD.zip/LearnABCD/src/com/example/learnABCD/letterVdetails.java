package com.example.learnABCD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class letterVdetails extends Activity implements OnClickListener
{
	
	
	ImageButton letterW;
	Button mainmenuV;
@Override
protected void onCreate(Bundle savedInstanceState) 
{
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.v);
	
	letterW=(ImageButton)findViewById(R.id.imageButton1);
	mainmenuV=(Button)findViewById(R.id.mainmenuV);
	mainmenuV.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentmainmenuv=new Intent(letterVdetails.this,LearnABCDActivity.class);
			startActivity(Intentmainmenuv);
			
		}
	});
	
	
letterW.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentw=new Intent(letterVdetails.this,letterWdetails.class);
			startActivity(Intentw);			
		}
	});

	
}


@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
