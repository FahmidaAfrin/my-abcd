package com.example.learnABCD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class letterTdetails extends Activity implements OnClickListener
{
	
	
	ImageButton letterU;
	Button mainmenuT;
@Override
protected void onCreate(Bundle savedInstanceState) 
{
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.t);
	
	letterU=(ImageButton)findViewById(R.id.imageButton1);
	mainmenuT=(Button)findViewById(R.id.mainmenuT);
	mainmenuT.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentmainmenut=new Intent(letterTdetails.this,LearnABCDActivity.class);
			startActivity(Intentmainmenut);
			
		}
	});
	
	
letterU.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentu=new Intent(letterTdetails.this,letterUdetails.class);
			startActivity(Intentu);			
		}
	});

	
}


@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
