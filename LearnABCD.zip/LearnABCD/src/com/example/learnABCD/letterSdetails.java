package com.example.learnABCD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class letterSdetails extends Activity implements OnClickListener
{
	
	
	ImageButton letterT;
	Button mainmenuS;
@Override
protected void onCreate(Bundle savedInstanceState) 
{
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.s);
	
	letterT=(ImageButton)findViewById(R.id.imageButton1);
	mainmenuS=(Button)findViewById(R.id.mainmenuS);
	mainmenuS.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentmainmenus=new Intent(letterSdetails.this,LearnABCDActivity.class);
			startActivity(Intentmainmenus);
			
		}
	});
	
	
letterT.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentt=new Intent(letterSdetails.this,letterTdetails.class);
			startActivity(Intentt);			
		}
	});

	
}


@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
