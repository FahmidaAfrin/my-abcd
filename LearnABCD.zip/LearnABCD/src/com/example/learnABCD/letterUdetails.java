package com.example.learnABCD;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class letterUdetails extends Activity implements OnClickListener
{
	
	
	ImageButton letterV;
	Button mainmenuU;
@Override
protected void onCreate(Bundle savedInstanceState) 
{
	
	
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
	setContentView(R.layout.u);
	
	letterV=(ImageButton)findViewById(R.id.imageButton1);
	mainmenuU=(Button)findViewById(R.id.mainmenuU);
	mainmenuU.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
					
			
			
			// TODO Auto-generated method stub
			Intent Intentmainmenuu=new Intent(letterUdetails.this,LearnABCDActivity.class);
			startActivity(Intentmainmenuu);
			
		}
	});
	
	
letterV.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent Intentv=new Intent(letterUdetails.this,letterVdetails.class);
			startActivity(Intentv);			
		}
	});

	
}


@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
